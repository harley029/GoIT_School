from django import forms
from django.forms import modelformset_factory
from .models import Author, Quote, Tag


class AuthorForm(forms.ModelForm):
    class Meta:
        model = Author
        fields = ["fullname", "born_date", "born_location", "description"]
        widgets = {
            "fullname": forms.TextInput(attrs={"class": "form-control"}),
            "born_date": forms.TextInput(attrs={"class": "form-control"}),
            "born_location": forms.TextInput(attrs={"class": "form-control"}),
            "description": forms.Textarea(attrs={"class": "form-control"}),
        }


class QuoteForm(forms.ModelForm):
    class Meta:
        model = Quote
        fields = ["quote", "author"]
        widgets = {
            "quote": forms.Textarea(attrs={"class": "form-control"}),
            "author": forms.Select(attrs={"class": "form-control"}),
        }

    def __init__(self, *args, **kwargs):
        tags = kwargs.pop('tags', [])  # Отримуємо теги з параметрів, переданих при ініціалізації форми
        super().__init__(*args, **kwargs)
        self.fields['tags'] = forms.ModelMultipleChoiceField(queryset=Tag.objects.all(), initial=tags, required=False, widget=forms.SelectMultiple(attrs={"class": "form-control"}))


# class TagForm(forms.ModelForm):
#     class Meta:
#         model = Tag
#         fields = ["name"]
#         widgets = {
#             "name": forms.TextInput(attrs={"class": "form-control"}),
#         }


# TagFormSet = modelformset_factory(Tag, form=TagForm, extra=1, can_delete=True)
