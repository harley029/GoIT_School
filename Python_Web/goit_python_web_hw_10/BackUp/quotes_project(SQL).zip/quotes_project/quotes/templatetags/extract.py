from django import template
from ..models import Author

register = template.Library()


@register.filter
def get_author(id_):
    try:
        author = Author.objects.get(pk=id_)
        return author.fullname
    except Author.DoesNotExist:
        return ""
