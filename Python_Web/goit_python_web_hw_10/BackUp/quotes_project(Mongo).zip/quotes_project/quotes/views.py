from bson import ObjectId
from django.shortcuts import render
from django.core.paginator import Paginator

from quotes.utils import get_mongodb

# Create your views here.
def main(request, page=1):
    db = get_mongodb()
    quotes = db.quotes.find()
    quotes_per_page = 10
    paginator = Paginator(list(quotes), quotes_per_page)
    quotes_on_page = paginator.page(page)
    return render(request, "quotes/index.html", context={"quotes": quotes_on_page})


def author_detail(request, author_id):
    db = get_mongodb()
    author = db.authors.find_one({"_id": ObjectId(author_id)})
    return render(request, "quotes/author_details.html", context={"author": author})


def tag_detail(request, tag_name, page=1):
    db = get_mongodb()
    quotes = db.quotes.find({"tags": tag_name})
    tags_per_page = 10
    paginator = Paginator(list(quotes), tags_per_page)
    tags_on_page = paginator.page(page)
    return render(
        request,
        "quotes/tag_details.html",
        context={"tag": tag_name, "quotes": tags_on_page},
    )
